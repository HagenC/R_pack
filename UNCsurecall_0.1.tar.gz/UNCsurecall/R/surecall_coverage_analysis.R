#' SureCall QC report analysis
#' @export
#' @title Analysis of SureCall QC reports
#' @name surecall_cov_DB, surecall_cov_analysis
#' @param DB_dir (directiory of QC report .txt files) or wd(directory of single QC report .txt)
#' @return Tables
#' @author UNC


#1. function:Create Unique ID for each and merge with other: calc mean coverage.
surecall_cov_DB <- function(DB_dir){
  setwd(DB_dir)
  listOFfiles = list.files(pattern="*.txt")
  tmp <- data.frame()
  for (i in 1:length(listOFfiles)) {
    tmp1 <- rbind(assign(listOFfiles[i], read.delim(listOFfiles[i],stringsAsFactors = FALSE)))
    NM_lines_1 <- tmp1[grep("NM", tmp1[,1]), ]
    NM_lines_2 <- data.frame(do.call('rbind', strsplit(as.character(NM_lines_1)," ",fixed=TRUE)))
    #tmp2 <- subset(tmp1, select = c("Impacted.Gene", "HOM.HET","Chrom", "Pos", "Ref.Allele", "Alt.Allele"))
    cols <- c("X1", "X2","X3")
    NM_lines_2$ID <- apply(NM_lines_2[, cols], 1 , paste, collapse="__")
    tmp <- rbind(tmp, NM_lines_2)
    i <- i+1
  }
  counting_table <- count(tmp, ID)
  tmp$X4 <- as.numeric(as.character(tmp$X4))
  sumExonCOV <- aggregate(cbind(X4)~ID, data= tmp, sum)
  merged_data <- merge(counting_table, sumExonCOV, by="ID")
  merged_data$cov.avg <- merged_data$X4/merged_data$n
  Split <- data.frame(do.call('rbind', strsplit(as.character(merged_data$ID),"__",fixed=TRUE)))
  merged_data <- cbind(merged_data, Split)
  merged_data$X4 <- NULL
  colnames(merged_data) <- c("ID", "n" ,"avg.cov", "gene", "accssion", "accession_exon")
  return(merged_data)
}



#2nd function: single-file coverage. Input file of genes that needs to be analyzed......
surecall_cov_analysis <- function(wdir){
  setwd(wdir)
  tmp <- data.frame()
  listOFfiles = list.files(pattern="*.txt")
  for (i in 1:length(listOFfiles)) {
    tmp1 <- rbind(assign(listOFfiles[i], read.delim(listOFfiles[i],stringsAsFactors = FALSE)))
    NM_lines_1 <- tmp1[grep("NM", tmp1[,1]), ]
    NM_lines_2 <- data.frame(do.call('rbind', strsplit(as.character(NM_lines_1)," ",fixed=TRUE)))
    cols <- c("X1", "X2","X3")
    NM_lines_2$ID <- apply(NM_lines_2[, cols], 1 , paste, collapse="__")
    tmp <- rbind(tmp, NM_lines_2)
    i <- i+1
  }
  colnames(tmp) <- c("gene", "accssion", "accession_exon", "<20_cov", "ID")
  tmp_filterd <- filter(tmp, gene != "C4B_2" & gene != "BBS12" & gene != "C4A" & gene != "C4B" & gene != "CSF2RA" &
                          gene != "DOLK" & gene != "FKRP" & gene != "FOXC1" & gene != "FOXC2" & gene != "IKBKG"  & gene != "KCNA5"
                        & gene != "KCNE3" & gene != "LEFTY2" & gene != "SBDS" & gene != "SMN1" )
  return(tmp_filterd)
}











